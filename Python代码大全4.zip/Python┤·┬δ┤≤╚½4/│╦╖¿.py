for i in range (100):
        for v in range(100):
                print( i, '*',v,'=',i*v )
