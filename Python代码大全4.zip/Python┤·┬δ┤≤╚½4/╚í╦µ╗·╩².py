from tkinter import *
from random import randint
def roll():
    text.delete(0.0,END)
    text.insert(END,randint(1,999))
window = Tk()
window.title('MinecraftEducationEdition_x86_1.17.30.52')
text = Text(window,width=100,height=30)
buttonA = Button(window,text='Press to roll',command=roll)
text.pack()
buttonA.pack()
