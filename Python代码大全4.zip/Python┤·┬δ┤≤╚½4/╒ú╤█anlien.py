from tkinter import *
window = Tk()
window.title("Draw a alien ")
#设定窗体大小（300*400）
c = Canvas(window, width=300, height=400)
c.pack()
#绘制椭圆形身体，左上角（100，50），右下角（300，250）
body = c.create_oval(100, 50, 300, 250, fill="green")
#绘制眼睛
eye = c.create_oval(170, 70, 230, 130, fill="white")
#绘制眼球
eyeball = c.create_oval(190, 90, 210, 110, fill="black")
#绘制嘴巴
mouth = c.create_oval(150, 220, 250, 240, fill="red")
#绘制脖子（线段），起点（200，150），终点（200，130）
neck = c.create_line(200, 150, 200, 130)
#绘制帽子（三角形），三个点（100，75，220，75，200，20）
bluehat = c.create_polygon(100, 75, 220, 75, 200, 20, fill="blue")
greenhat = c.create_polygon(100, 75, 220, 75, 200, 20, fill="green")
orangehat = c.create_polygon(100, 75, 220, 75, 200, 20, fill="orange")

def mouth_open():
    c.itemconfig(mouth,fill="black")
def mouth_close():
    c.itemconfig(mouth,fill="red")
def blink():
    c.itemconfig(eye,fill="green")
    c.itemconfig(eyeball,state=HIDDEN)
def unblink():
    c.itemconfig(eye,fill="white")
    c.itemconfig(eyeball,state=NORMAL)

word = c.create_text(200,280,text="I am alien")
def steal_blue_hat():
    c.itemconfig(bluehat,state=HIDDEN)
    c.itemconfig(word,text="Give my hat back!")
def steal_green_hat():
    c.itemconfig(greenhat,state=HIDDEN)
    c.itemconfig(word,text="Give my hat back!")
def steal_orange_hat():
    c.itemconfig(orangehat,state=HIDDEN)
    c.itemconfig(word,text="Give my hat back!")
def return_orange_hat():
    c.itemconfig(orangehat,state=NORMAL)
    c.itemconfig(word,text="Thank you this is  my hat!")
def return_blue_hat():
    c.itemconfig(bluehat,state=NORMAL)
    c.itemconfig(word,text="Ummmm,this is not my hat!")
def return_green_hat():
    c.itemconfig(greenhat,state=NORMAL)
    c.itemconfig(word,text="I don't like green hats!")
window.attributes("-topmost",True)
def burp(event):
    mouth_open()
    c.itemconfig(word,text="Burp!")
c.bind_all("<Button-1>",burp)

def eye_control(event):
    key = event.keysym
    if key =="Up":
        c.move(eyeball,0,-1)
    elif key =="Down":
        c.move(eyeball,0,1)
    elif key =="Left":
        c.move(eyeball,-1,0)
    elif key =="Right":
        c.move(eyeball,1,0)
c.bind_all("<Key>",eye_control)
        
        
    


