import turtle
t=turtle.Pen()
t.speed(0)
t.pencolor('yellow')
number_of_circles=int(turtle.numinput('Number of circles','How many circles in your rosette?',6))
for x in range (1000000000000000000000000000000000000000000):
    t.circle(100)
    t.left(360/number_of_circles)
