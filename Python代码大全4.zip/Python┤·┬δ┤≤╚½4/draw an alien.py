from tkinter import *
window = Tk()
window.title('Minecraft Education for windows x86')
c = Canvas(window, width=300, height=400)
c.pack()
body = c.create_(100,300, fill('mine.jfif'))
