for i in range(10):
    for v in range(10):
        print(i'*'v '='i*v)
