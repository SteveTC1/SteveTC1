import turtle
t=turtle.Pen()
t.speed(0)
def up():
    t.forward(10)
def left():
    t.left(45)
def right():
    t.right(45)
turtle.onkeypress(up,'Up')
turtle.onkeypress(left,'Left')
turtle.onkeypress(right,'Right')
turtle.listen()
