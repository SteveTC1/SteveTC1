answer=input('Do you want to see a spiral?y/n:')
if answer =='y':
    print('Working...')
    import turtle
    t= turtle.Pen()
    t.speed(0)
    t.width(2)
    for x in range(1000000000000000):
        for v in range(1):
            for z in range(1):
                t.pencolor('lightgreen')
                t.circle(x)
            t.pencolor('blue')
            t.forward(x)
        t.pencolor('gold')
        t.forward(x*2)
        t.left(88)
print('Okay we are done')
