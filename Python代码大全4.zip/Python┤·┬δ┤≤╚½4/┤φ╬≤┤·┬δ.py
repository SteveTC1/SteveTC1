while True
for x import cycle:
    print('h')
    
