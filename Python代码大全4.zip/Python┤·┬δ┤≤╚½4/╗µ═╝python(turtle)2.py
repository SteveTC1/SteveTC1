import turtle
t=turtle.Pen()
t.pencolor('yellow')
t.speed(0)
for x in range(1000000):
    t.forward(200)
    t.left(120)
