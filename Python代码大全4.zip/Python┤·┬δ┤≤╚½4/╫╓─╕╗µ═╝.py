import turtle
t=turtle.Pen()
t.speed(0)
turtle.bgcolor('black')
colors=['red','gold','yellow','green','blue','purple']
name=turtle.textinput('Enter your name here:','What is your name?')
for x in range (100000000000000000000):
    t.pencolor(colors[x%6])
    t.penup()
    t.forward(x*4)
    t.pendown()
    t.write(name,font=('Arial',int((x+4)/4),'bold'))
    t.left(88)
