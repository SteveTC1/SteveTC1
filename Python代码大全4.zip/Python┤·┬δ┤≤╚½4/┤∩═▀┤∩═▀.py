import turtle
t=turtle.Pen()
t.speed(0)
turtle.onscreenclick(t.setpos)
turtle.bgcolor('yellow')
t.pencolor('red')
t.width(5)
