import turtle
t=turtle.Pen()
for x in range(1000000):
    t.forward(200)
    t.left(90)
